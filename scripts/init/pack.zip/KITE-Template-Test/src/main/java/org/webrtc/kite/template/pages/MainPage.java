package org.webrtc.kite.template.pages;

import io.cosmosoftware.kite.pages.BasePage;
import io.cosmosoftware.kite.interfaces.Runner;

import static io.cosmosoftware.kite.util.WebDriverUtils.loadPage;

public class MainPage extends BasePage {
  
  
  public MainPage(Runner runner) {
    super(runner);
  }
  
  public void open(String url) {
    loadPage(webDriver, url, 20);
  }
  
}

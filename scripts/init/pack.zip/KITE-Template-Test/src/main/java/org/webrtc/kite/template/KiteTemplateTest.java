package org.webrtc.kite.template;

import org.webrtc.kite.template.checks.MyFirstCheck;
import org.webrtc.kite.template.steps.OpenUrlStep;
import org.webrtc.kite.tests.KiteBaseTest;
import org.webrtc.kite.tests.TestRunner;

public class KiteTemplateTest extends KiteBaseTest {

  @Override
  protected void payloadHandling() {
    super.payloadHandling();
    if (this.payload != null) {
      //process payload here
    }
  }

  @Override
  public void populateTestSteps(TestRunner runner) {
    runner.addStep(new OpenUrlStep(runner, url));
    runner.addStep(new MyFirstCheck(runner));
  }

}
